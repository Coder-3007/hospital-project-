<?php

$name = $_POST['name']
$visitor_email = $_POST['email']
$message = $_POST['message']

$email_from = 'mansoor300@gmail.com';
$email_subject = "MAKE AN APPOINTMENT";
$email_body = "User Name: $name.\n"."/User Email : $visitor_email.\n"."/User Message : $message.\n".

$to = "abujan300@gmail.com"
$headers = "FROM: $email_from \r\n";
$headers = "Reply-to: $visitor_email \r\n";
mail($to,$email_subject,$email_body,$headers);
header("Location: t1.html")


?>